
@extends('Backend.Layouts.master')
@section('title', 'Dashboard')
@section('master-content')
        <!-- Dashboard Content -->
      <div class="content">
        <div class="content-header">
          <div>
            <h1 class="page-title">Dashboard Overview</h1>
            <p class="page-subtitle">Welcome back! Here's what's happening today.</p>
          </div>
          <button class="primary-btn">
            <i class="fas fa-download"></i>
            Export Report
          </button>
        </div>

        <!-- Stats Cards -->
        <div class="stats-grid">
          <div class="stat-card">
            <div class="stat-icon purple">
              <i class="fas fa-users"></i>
            </div>
            <div class="stat-info">
              <p class="stat-label">Total Users</p>
              <h3 class="stat-value">24,583</h3>
              <div class="stat-trend positive">
                <i class="fas fa-arrow-up"></i>
                <span>12.5% from last month</span>
              </div>
            </div>
          </div>

          <div class="stat-card">
            <div class="stat-icon blue">
              <i class="fas fa-shopping-cart"></i>
            </div>
            <div class="stat-info">
              <p class="stat-label">Total Orders</p>
              <h3 class="stat-value">8,426</h3>
              <div class="stat-trend positive">
                <i class="fas fa-arrow-up"></i>
                <span>8.3% from last month</span>
              </div>
            </div>
          </div>

          <div class="stat-card">
            <div class="stat-icon green">
              <i class="fas fa-dollar-sign"></i>
            </div>
            <div class="stat-info">
              <p class="stat-label">Total Revenue</p>
              <h3 class="stat-value">$128,492</h3>
              <div class="stat-trend positive">
                <i class="fas fa-arrow-up"></i>
                <span>18.2% from last month</span>
              </div>
            </div>
          </div>

          <div class="stat-card">
            <div class="stat-icon orange">
              <i class="fas fa-chart-line"></i>
            </div>
            <div class="stat-info">
              <p class="stat-label">Growth Rate</p>
              <h3 class="stat-value">23.8%</h3>
              <div class="stat-trend negative">
                <i class="fas fa-arrow-down"></i>
                <span>2.1% from last month</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Charts Section -->
        <div class="charts-grid">
          <div class="chart-card large">
            <div class="card-header">
              <h3 class="card-title">Revenue Overview</h3>
              <div class="card-actions">
                <button class="filter-btn active">Week</button>
                <button class="filter-btn">Month</button>
                <button class="filter-btn">Year</button>
              </div>
            </div>
            <div class="chart-container">
              <canvas id="revenueChart"></canvas>
            </div>
          </div>

          <div class="chart-card">
            <div class="card-header">
              <h3 class="card-title">Traffic Sources</h3>
              <button class="icon-btn small">
                <i class="fas fa-ellipsis-v"></i>
              </button>
            </div>
            <div class="traffic-list">
              <div class="traffic-item">
                <div class="traffic-source">
                  <i class="fab fa-google"></i>
                  <span>Google Search</span>
                </div>
                <div class="traffic-stats">
                  <span class="percentage">42%</span>
                  <div class="progress-bar">
                    <div class="progress-fill" style="width: 42%"></div>
                  </div>
                </div>
              </div>
              <div class="traffic-item">
                <div class="traffic-source">
                  <i class="fab fa-facebook"></i>
                  <span>Facebook</span>
                </div>
                <div class="traffic-stats">
                  <span class="percentage">28%</span>
                  <div class="progress-bar">
                    <div class="progress-fill" style="width: 28%"></div>
                  </div>
                </div>
              </div>
              <div class="traffic-item">
                <div class="traffic-source">
                  <i class="fab fa-twitter"></i>
                  <span>Twitter</span>
                </div>
                <div class="traffic-stats">
                  <span class="percentage">18%</span>
                  <div class="progress-bar">
                    <div class="progress-fill" style="width: 18%"></div>
                  </div>
                </div>
              </div>
              <div class="traffic-item">
                <div class="traffic-source">
                  <i class="fas fa-link"></i>
                  <span>Direct</span>
                </div>
                <div class="traffic-stats">
                  <span class="percentage">12%</span>
                  <div class="progress-bar">
                    <div class="progress-fill" style="width: 12%"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Recent Activity -->
        <div class="activity-card">
          <div class="card-header">
            <h3 class="card-title">Recent Activity</h3>
            <a href="#" class="view-all">View All</a>
          </div>
          <div class="activity-list">
            <div class="activity-item">
              <div class="activity-icon blue">
                <i class="fas fa-user-plus"></i>
              </div>
              <div class="activity-content">
                <p class="activity-text"><strong>Sarah Wilson</strong> registered as a new user</p>
                <p class="activity-time">2 minutes ago</p>
              </div>
            </div>
            <div class="activity-item">
              <div class="activity-icon green">
                <i class="fas fa-check-circle"></i>
              </div>
              <div class="activity-content">
                <p class="activity-text"><strong>Order #4892</strong> has been completed</p>
                <p class="activity-time">15 minutes ago</p>
              </div>
            </div>
            <div class="activity-item">
              <div class="activity-icon purple">
                <i class="fas fa-star"></i>
              </div>
              <div class="activity-content">
                <p class="activity-text"><strong>Product XYZ</strong> received a 5-star review</p>
                <p class="activity-time">1 hour ago</p>
              </div>
            </div>
            <div class="activity-item">
              <div class="activity-icon orange">
                <i class="fas fa-exclamation-triangle"></i>
              </div>
              <div class="activity-content">
                <p class="activity-text"><strong>Low stock alert</strong> for Product ABC</p>
                <p class="activity-time">3 hours ago</p>
              </div>
            </div>
          </div>
        </div>
      </div>

@endsection

@push('script')


<script>


</script>
@endpush

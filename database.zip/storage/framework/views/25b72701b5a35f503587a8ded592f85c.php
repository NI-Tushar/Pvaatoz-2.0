<?php $__env->startSection('app-content'); ?>
<div class="dashboard">
  <!-- Main Sidebar Container -->
  <?php if ($__env->exists('Backend.Includes.sidebar')) echo $__env->make('Backend.Includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main Content -->
    <main class="main-content">
      <?php if ($__env->exists('Backend.Includes.navbar')) echo $__env->make('Backend.Includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->yieldContent('master-content'); ?>

    <!--footer content-->
    <?php if ($__env->exists('Backend.Includes.footer')) echo $__env->make('Backend.Includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--footer content end-->
 </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH B:\xampp\htdocs\AccueVault\resources\views/Backend/Layouts/master.blade.php ENDPATH**/ ?>